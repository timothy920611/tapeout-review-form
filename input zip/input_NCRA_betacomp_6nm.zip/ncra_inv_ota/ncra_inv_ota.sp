* ======================================================================
* ncra_inv_ota  --  osiris cell   [paper: Kwon et al., TCAS-II 72(5), May 2025]
*   'A 10b 500MS/s Pipelined SAR ADC w/ Feedback-Factor Compensation, 6nm FinFET'
* Single-stage inverter-based OTA (residue amp), analog supply 0.78 V.
* Targets w/ NC: AOL >= 48 dB, fu >= 4.9 GHz, stage gain GS = 16x in 700 ps.
* [UNVERIFIED-ESTIMATE] fin counts + L: brief omits device sizes.
* CMFB shown switched-cap in paper; here reduced to passive sense for AC.
*   [PDK-CHECK-REQUIRED] blueprint model names; brief gives no device sizes
.subckt ncra_inv_ota VDDA VIP VIN VOUTP VOUTN VCM VSS
MP1  VOUTP VIP  VDDA VDDA PMOS_SLFin  W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MP2  VOUTN VIN  VDDA VDDA PMOS_SLFin  W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MN1  VOUTP VIP  VSS  VSS  NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MN2  VOUTN VIN  VSS  VSS  NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
CLa_p  VOUTP VSS  60.0f $ CLa incl. routing parasitic (paper)
CLa_n  VOUTN VSS  60.0f $ CLa incl. routing parasitic (paper)
RcmP   VOUTP VCM  5K    $ passive CMFB sense
RcmN   VOUTN VCM  5K    $ passive CMFB sense
Ccmfb  VCM   VSS  15.0f $ CMFB bypass
Cdec   VDDA  VSS  50.0f $ local decap
.ends ncra_inv_ota
