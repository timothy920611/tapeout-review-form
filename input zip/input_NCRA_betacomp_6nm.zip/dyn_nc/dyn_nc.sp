* ======================================================================
* dyn_nc  --  osiris cell   [paper: Kwon et al., TCAS-II 72(5), May 2025]
*   'A 10b 500MS/s Pipelined SAR ADC w/ Feedback-Factor Compensation, 6nm FinFET'
* Dynamic NC at virtual ground for feedback-factor (beta) compensation.
* beta 0.059 -> 0.24 (x4.07 relaxation of AOL/fu). k = 0.8.
* [UNVERIFIED-ESTIMATE] inverter fin counts; CN = 147.5 fF/side (=295/2).
*   [PDK-CHECK-REQUIRED] blueprint model names; brief gives no device sizes
.subckt dyn_nc VDD VINP VINN VOUTP VOUTN VSS
MPp  VOUTP VINP VDD VDD PMOS_SLFin  W={ZZZ*110e-9} L=12n NFIN=ZZZ M=1
MNp  VOUTP VINP VSS VSS NMOS_6nm_HP W={ZZZ*110e-9} L=6n NFIN=ZZZ M=1
MPn  VOUTN VINN VDD VDD PMOS_SLFin  W={ZZZ*110e-9} L=12n NFIN=ZZZ M=1
MNn  VOUTN VINN VSS VSS NMOS_6nm_HP W={ZZZ*110e-9} L=6n NFIN=ZZZ M=1
CNp  VOUTP VINP 147.5f $ NC cap, 295fF/2 (paper)
CNn  VOUTN VINN 147.5f $ NC cap, 295fF/2 (paper)
ClP  VOUTP VSS  10.0f  $ load
ClN  VOUTN VSS  10.0f  $ load
.ends dyn_nc
