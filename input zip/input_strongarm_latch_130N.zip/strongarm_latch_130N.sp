* ======================================================================
* SA_COMPARATOR_TOP_130N  --  StrongARM latch comparator (130nm PDK)
* Ref: B. Razavi, "The StrongARM Latch [A Circuit for All Seasons],"
*      IEEE Solid-State Circuits Mag., vol. 7, no. 2, pp. 12-17, 2015.
* Topology: Fig. 1(b) -- clocked input pair M1-M2, cross-coupled NMOS
*   M3-M4 and PMOS M5-M6, four CK precharge switches S1-S4, CK tail;
*   nodes P/Q (input-pair drains) and X/Y (rail-to-rail outputs), followed
*   by a NAND SR latch that holds the pulsed decision.
* Sizing hooks: nf hooks on tail + input pair + both cross-coupled pairs.
* ======================================================================

.SUBCKT INV_130N VDD VIN VOUT VSS
MM_n  VOUT VIN VSS  VSS  nmos W=0.5u L=0.13u nf=2 m=2
MM_p  VOUT VIN VDD  VDD  pmos W=1.0u L=0.13u nf=2 m=2
.ENDS

.SUBCKT NAND2_130N A B VDD VOUT VSS
MM_p0  VOUT A   VDD  VDD  pmos W=1u L=0.13u nf=2 m=2
MM_p1  VOUT B   VDD  VDD  pmos W=1u L=0.13u nf=2 m=2
MM_n0  VOUT A   net0 VSS  nmos W=1u L=0.13u nf=2 m=2
MM_n1  net0 B   VSS  VSS  nmos W=1u L=0.13u nf=2 m=2
.ENDS

* --- StrongARM latch core (Razavi Fig. 1b) : D G S B order ---
.SUBCKT STRONGARM_130N CK VDD VINP VINN X Y VSS
MM_tail  net_tail CK    VSS      VSS  nmos W=1.0u L=0.13u nf=ZZZ m=2
MM_in_p  net_p    VINP  net_tail VSS  nmos W=1.0u L=0.13u nf=ZZZ m=2
MM_in_n  net_q    VINN  net_tail VSS  nmos W=1.0u L=0.13u nf=ZZZ m=2
MM_xn_p  X        Y     net_p    VSS  nmos W=0.5u L=0.13u nf=ZZZ m=2
MM_xn_n  Y        X     net_q    VSS  nmos W=0.5u L=0.13u nf=ZZZ m=2
MM_xp_p  X        Y     VDD      VDD  pmos W=1.0u L=0.13u nf=ZZZ m=2
MM_xp_n  Y        X     VDD      VDD  pmos W=1.0u L=0.13u nf=ZZZ m=2
MM_pc_p  net_p    CK    VDD      VDD  pmos W=0.5u L=0.13u nf=2 m=2
MM_pc_q  net_q    CK    VDD      VDD  pmos W=0.5u L=0.13u nf=2 m=2
MM_pc_x  X        CK    VDD      VDD  pmos W=0.5u L=0.13u nf=2 m=2
MM_pc_y  Y        CK    VDD      VDD  pmos W=0.5u L=0.13u nf=2 m=2
MM_clx   VSS      X     VSS      VSS  nmos W=0.5u L=0.13u nf=2 m=2
MM_cly   VSS      Y     VSS      VSS  nmos W=0.5u L=0.13u nf=2 m=2
.ENDS

* --- NAND SR latch holding the pulsed StrongARM outputs (active-low) ---
.SUBCKT SR_LATCH_130N SB RB VDD Q QB VSS
XI_n0  SB QB VDD Q  VSS NAND2_130N
XI_n1  RB Q  VDD QB VSS NAND2_130N
.ENDS

* --- TOP: StrongARM + SR latch ---
.SUBCKT SA_COMPARATOR_TOP_130N VDD VSS CK VINP VINN VOUTP VOUTN
XI_sa  CK VDD VINP VINN net_x net_y VSS STRONGARM_130N
XI_sr  net_x net_y VDD VOUTP VOUTN VSS SR_LATCH_130N
.ENDS
