* ======================================================================
* nc_resamp_inv_ota  --  NC-assisted Residue-Amplifier inverter-OTA (osiris cell)
*   Source: AnalogAgent_NC_ResAmp_6nm_GAA_fixed_v6  ->  INV_OTA_6N
*   Swept knob: NFIN (fin count) via ZZZ placeholder  [osiris nf <-> 6nm NFIN]
*   [PDK-CHECK-REQUIRED] NMOS_6nm_HP / PMOS_SLFin are blueprint model names;
*   supply real 6nm BSIM-CMG cards + .lib before simulating.
*   [NOTE] VBIAS port dangling post Fix-23 (kept for interface fidelity).
* ======================================================================
.subckt nc_resamp_inv_ota VDD_ANA VIP VIN VOUTP VOUTN VCM VBIAS VSS
MM_mp1  VOUTP VIP  VDD_ANA VDD_ANA PMOS_SLFin  W='ZZZ*110n' L=36n NFIN=ZZZ M=1
MM_mp2  VOUTN VIN  VDD_ANA VDD_ANA PMOS_SLFin  W='ZZZ*110n' L=36n NFIN=ZZZ M=1
MM_mn1  VOUTP VIP  VSS     VSS     NMOS_6nm_HP W='ZZZ*110n' L=36n NFIN=ZZZ M=1
MM_mn2  VOUTN VIN  VSS     VSS     NMOS_6nm_HP W='ZZZ*110n' L=36n NFIN=ZZZ M=1
CC_la_p  VOUTP VSS  42.0f $[MOMCAP_6nm_M4M7] M=1
CC_la_n  VOUTN VSS  42.0f $[MOMCAP_6nm_M4M7] M=1
CC_cmfb  VCM   VSS  15.0f $[MOMCAP_6nm_M4M7] M=1
RR_cm_p  VOUTP VCM  5K  $[RP_6nm_M7] M=1
RR_cm_n  VOUTN VCM  5K  $[RP_6nm_M7] M=1
CC_ldec_p VDD_ANA VSS  50.0f $[MOMCAP_6nm_M4M7_ENCAP] M=1
CC_ldec_n VDD_ANA VSS  50.0f $[MOMCAP_6nm_M4M7_ENCAP] M=1
.ends nc_resamp_inv_ota
