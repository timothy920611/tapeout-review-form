* ======================================================================
* dyn_nc_inv  --  osiris cell (v3)   [extracted from NC_ResAmp_6nm_GAA_fixed_v6]
*   Swept knob: NFIN via ZZZ  [osiris nf <-> 6nm NFIN], W={ZZZ*110e-9} (Weff_unit)
*   [PDK-CHECK-REQUIRED] blueprint model names, supply real BSIM-CMG cards
* ======================================================================
.subckt dyn_nc_inv VDD VINP VINN VOUTP VOUTN VSS
MM_nc_np  VOUTP VINP VDD VDD PMOS_SLFin  W={ZZZ*110e-9} L=12n NFIN=ZZZ M=1
MM_nc_nn  VOUTP VINP VSS VSS NMOS_6nm_HP W={ZZZ*110e-9} L=6n NFIN=ZZZ M=1
MM_nc_pp  VOUTN VINN VDD VDD PMOS_SLFin  W={ZZZ*110e-9} L=12n NFIN=ZZZ M=1
MM_nc_pn  VOUTN VINN VSS VSS NMOS_6nm_HP W={ZZZ*110e-9} L=6n NFIN=ZZZ M=1
CC_l_p  VOUTP VSS 10.0f $ MOMCAP_6nm_M4M7
CC_l_n  VOUTN VSS 10.0f $ MOMCAP_6nm_M4M7
.ends dyn_nc_inv
