* ======================================================================
* nc_resamp_inv_ota  --  osiris cell (v3)   [extracted from NC_ResAmp_6nm_GAA_fixed_v6]
*   Swept knob: NFIN via ZZZ  [osiris nf <-> 6nm NFIN], W={ZZZ*110e-9} (Weff_unit)
*   [PDK-CHECK-REQUIRED] blueprint model names, supply real BSIM-CMG cards
* ======================================================================
.subckt nc_resamp_inv_ota VDD_ANA VIP VIN VOUTP VOUTN VCM VBIAS VSS
MM_mp1  VOUTP VIP  VDD_ANA VDD_ANA PMOS_SLFin  W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_mp2  VOUTN VIN  VDD_ANA VDD_ANA PMOS_SLFin  W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_mn1  VOUTP VIP  VSS     VSS     NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_mn2  VOUTN VIN  VSS     VSS     NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
CC_la_p  VOUTP VSS  42.0f $ MOMCAP_6nm_M4M7
CC_la_n  VOUTN VSS  42.0f $ MOMCAP_6nm_M4M7
CC_cmfb  VCM   VSS  15.0f $ MOMCAP_6nm_M4M7
RR_cm_p  VOUTP VCM  5K    $ RP_6nm_M7
RR_cm_n  VOUTN VCM  5K    $ RP_6nm_M7
CC_ldec_p VDD_ANA VSS 50.0f $ MOMCAP_6nm_M4M7_ENCAP
CC_ldec_n VDD_ANA VSS 50.0f $ MOMCAP_6nm_M4M7_ENCAP
.ends nc_resamp_inv_ota
