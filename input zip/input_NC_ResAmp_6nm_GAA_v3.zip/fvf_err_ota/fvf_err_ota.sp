* ======================================================================
* fvf_err_ota  --  osiris cell (v3)   [extracted from NC_ResAmp_6nm_GAA_fixed_v6]
*   Swept knob: NFIN via ZZZ  [osiris nf <-> 6nm NFIN], W={ZZZ*110e-9} (Weff_unit)
*   [PDK-CHECK-REQUIRED] blueprint model names, supply real BSIM-CMG cards
* ======================================================================
.subckt fvf_err_ota VDD_09 VINP VINN VOUTA VSS
MM_ea_ip  VOUTA   VINP VDD_09 VDD_09 PMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_ea_in  net_ean VINN VDD_09 VDD_09 PMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_ea_ln  net_ean net_ean VSS  VSS   NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
MM_ea_lp  VOUTA   net_ean VSS  VSS   NMOS_6nm_HP W={ZZZ*110e-9} L=36n NFIN=ZZZ M=1
.ends fvf_err_ota
